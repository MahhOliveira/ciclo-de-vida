package com.example.sharedexerccio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    //achar os ids que vai usar
        val dadoinserido = findViewById<Text>(R.id.dadoinserido)
        val botaosalvar = findViewById<Button>(R.id.botaosalvar)
        val textosalvo = findViewById<TextView>(R.id.textosalvo)
        //
        val sharedPreferences = getSharedPreferences("minhas preferencias",context.mode private)

    botaosalvar.setOnClickListener { R.View
    val dadodigitado = dadoinserido.text.tostring()
    textosalvo.text = dadodigitado
        dadoinserido.text.clear()


        val  editor = sharedPreferences.edit()
        editor.putString("dado", dadodigitado)
        editor.apply {  }

    }
        val dadopersistido = sharedPreferences.getString("dado", "")
        if(!dadopersistido : isNull0rBlank()){
         textosalvo.text = dado salvo: $ dadopersistido


        }
    }
}