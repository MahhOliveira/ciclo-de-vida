package com.example.desafiociclodevida

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    lateinit var texto : TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        texto = findViewById(R.id.texto)
        texto.text = "oncreate() foi chamado"




    }
override fun onstart(){
  super : onstart(savedinstanceState)
    texto.text = "onstart() foi chamado"




}

    override fun onResume() {
        super.onResume(savedinstanceState)
        texto.text = "onresume() foi chamado"
    }

    override fun onPause() {
        super.onPause(savedinstanceState)
        texto.text = "onpause() foi chamado"
    }


    }







